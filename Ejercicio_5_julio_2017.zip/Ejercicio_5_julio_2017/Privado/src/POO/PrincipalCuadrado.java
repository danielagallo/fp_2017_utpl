/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package POO;

import java.util.Scanner;

/**
 *
 * @author Salas
 */
public class PrincipalCuadrado {

    public static void main(String[] args) {
        //Este método es para ingresar valores
        Scanner entrada = new Scanner(System.in);

        for (int i = 1; i <= 5; i++) {
            System.out.println("Ingrese el valor de lado:");
            int lado = entrada.nextInt();
            Cuadrado c = new Cuadrado();
            c.agregar_lado(lado);
            System.out.printf("Cuadrado con lado %d\n\tÁrea =%d\n\tPerimetro =%d\n", c.obtener_lado(), c.calcular_area(), c.calcular_perimetro());
        }
    }
}
