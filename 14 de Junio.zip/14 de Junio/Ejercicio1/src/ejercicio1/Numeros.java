/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio1;
import java.util.Scanner;

/**
 *
 * @author Salas
 */
public class Numeros {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Presenta imprimir = new Presenta(); 
        Scanner entrada = new Scanner(System.in);
        System.out.println("Ingrese su nombre:");
        String minombre = entrada.nextLine();
        System.out.println("Tipo de Reporte (1)-(2):");
        int tipo = entrada.nextInt();

        if (tipo == 1) {
            imprimir.presentar_mayusculas(minombre);
        }else{
            if(tipo==2){
               imprimir.presentar_minusculas(minombre);
                        }else{
                System.out.printf("No hay Reporte");
            }
        }
    }

}
