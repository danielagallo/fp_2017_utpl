/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio1;

/**
 *
 * @author Salas
 */
public class Operacion {

    public void suma(int a, int b) {
        int suma = a + b;
        System.out.printf("La suma de %d más %d \n es igual a: \n\t%d", a, b, suma);
    }

    public void resta(int a, int b) {
        int resta = a - b;
        System.out.printf("La resta de %d menos %d \n es igual a: \n\t%d", a, b, resta);
    }

    public void multiplicacion(int a, int b) {
        int multi = (a * b);
        System.out.printf("La multiplicación de %d por %d \n es igual a: \n\t%d", a, b, multi);
    }

    public void division(int a, int b) {
        double div = ((double) a / (double) b);
        System.out.printf("La división de %d dividido para %d \n es igual a: \n\t%.2f", a, b, div);
    }

    public void impresion(int opcion, int a, int b) {
        switch (opcion) {
            case 1:
                suma(a, b);
                break;
            case 2:
                resta(a, b);
                break;
            case 3:
                multiplicacion(a, b);
                break;
            case 4:
                division(a, b);
                break;
            default:
                System.out.println("Opción Incorrecta");
                break;
        }
    }
}
