/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio1;

import java.util.Scanner;

/**
 *
 * @author Salas
 */
public class Principal {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        Operacion op = new Operacion();
        System.out.println("Ingrese el primer Número:");
        int num1 = entrada.nextInt();
        System.out.println("Ingrese el segundo Número:");
        int num2 = entrada.nextInt();
        System.out.println("Que Operación desea hacer: \n (1)Suma \n (2)Resta \n (3)Multiplicación \n (4)División");
        int opcion = entrada.nextInt();
        op.impresion(opcion, num1, num2);
        }
    }

